
              EXECUTABLES FOR THE PIPELINE

If you have need to use a system that is of a specific architecture, such as
bit size, OS, CPU type then please create a folder and put the compatible 
binaries in that folder.  For example, if you use Debian linux then please put the
compiled binaries in a folder called "debian"

The binaries used in the pipeline can be compiled from the sources folder in the 
executables folder
