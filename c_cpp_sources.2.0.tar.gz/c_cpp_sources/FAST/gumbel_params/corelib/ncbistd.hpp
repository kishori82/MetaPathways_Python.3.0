#ifndef CORELIB___NCBISTD__HPP
#define CORELIB___NCBISTD__HPP

//#include <corelib/ncbistr.hpp>
#include <corelib/ncbistl.hpp>
#include <corelib/ncbidbg.hpp>
#include <corelib/ncbitype.h>
#include <string.h>

#endif  /* CORELIB___NCBISTD__HPP */
