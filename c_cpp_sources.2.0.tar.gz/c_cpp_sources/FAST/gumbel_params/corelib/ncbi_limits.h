#ifndef CORELIB___NCBI_LIMITS__H
#define CORELIB___NCBI_LIMITS__H

#include <limits.h>

const Int4  kMin_I4  = INT_MIN;
const Int4  kMax_I4  = INT_MAX;

#endif /* CORELIB___NCBI_LIMITS__H */
