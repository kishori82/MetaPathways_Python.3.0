#ifndef COMMON___NCBI_EXPORT__H
#define COMMON___NCBI_EXPORT__H

#define NCBI_XUTIL_EXPORT

#endif  /*  COMMON___NCBI_EXPORT__H  */
